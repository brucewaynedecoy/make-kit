---
title: "{{TITLE}}"
kind: "guide"
status: "draft"
path: "{{PATH}}"
persona: "maintainer"
# version: ""
# order: 100
# tags: []
# applies-to: []
# related: []
---

# {{TITLE}}

<!-- Select an effective Persona with the `maintainer` primitive from the built-in defaults plus valid project config. Set `persona` to that slug and write under `docs/assets/<persona-slug>/`. The built-in default is `maintainer`. Either role can be human or agent; do not infer the audience from the author. -->

> See `.make-docs/system/contracts/guide-contract.md` for frontmatter schema, slug rules, audience rules, coverage decisions, and future coverage handling.

## Overview

What this guide helps contributors, maintainers, integrators, or operators do.

## Project Orientation

Where the relevant code, docs, generated files, contracts, and source-of-truth artifacts live.

## Prerequisites

Tools, access, local setup, or project knowledge required before starting.

## Maintenance Workflow

How to change, extend, maintain, validate, or troubleshoot this capability.

## Validation

Commands, checks, review points, or evidence that show the change is working.

## Troubleshooting

Common failures, likely causes, and recovery steps.

## Related Resources

Links to related guides, designs, PRDs, work backlogs, history records, or reference contracts.

<!--
## Future Coverage

Use this section only when confirmed downstream work should update this guide later.

- Blocked by: <phase, capability, decision, or artifact>
  Update when: <concrete trigger>
  Guide change: <what to add, revise, or remove>
-->

<!-- Headings above are suggestions. Add, remove, or rename sections to fit the guide's content while preserving the audience intent in the guide contract. -->
